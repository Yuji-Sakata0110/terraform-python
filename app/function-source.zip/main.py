from fastapi import FastAPI
from annotated_types import Any

app = FastAPI()


@app.get("/")
def read_root() -> dict[str]:
    return {"message": "Hello, World!"}


@app.get("/items/{item_id}")
def read_item(item_id: int, query_param: str = None) -> dict[str, Any]:
    return {"item_id": item_id, "query_param": query_param}


def helloHttp() -> None:
    print("start")
